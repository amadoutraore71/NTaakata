export default function generateMapHtml({
  mode = "drivers",
  passengerLocation,
  driverLocation = null,
  drivers = [],
  searchingDriver = null,
  icons = {},
  destinationLocation = null,
}) {
  const passenger = passengerLocation || { latitude: 0, longitude: 0 };
  const initialDrivers = Array.isArray(drivers) ? drivers : [];
  const driver = driverLocation || null;
  const searching = searchingDriver || null;
  const destination = destinationLocation || null;

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<style>
html,body,#map{width:100%;height:100%;margin:0;padding:0;overflow:hidden;background:#dfe7e3}
.leaflet-container{background:#dfe7e3}
.vehicle-icon,.passenger-icon{background:transparent!important;border:0!important;box-shadow:none!important}
.vehicle-icon svg,.passenger-icon svg{display:block;width:100%;height:100%}
</style>
</head>
<body>
<div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
(function(){
"use strict";

const MODE=${JSON.stringify(mode)};
const PASSENGER=${JSON.stringify(passenger)};
const INITIAL_DRIVER=${JSON.stringify(driver)};
const INITIAL_DRIVERS=${JSON.stringify(initialDrivers)};
const SEARCHING_DRIVER=${JSON.stringify(searching)};
const INITIAL_DESTINATION=${JSON.stringify(destination)};
const ICONS=${JSON.stringify(icons || {})};

function send(type,payload){
  try{window.ReactNativeWebView.postMessage(JSON.stringify(Object.assign({type:type},payload||{})));}catch(e){}
}
function debug(message){send("debug",{message:String(message)});}
window.onerror=function(message,source,line,column,error){
  send("webview_js_error",{message:String(message||""),source:String(source||""),line:Number(line)||0,column:Number(column)||0,stack:error&&error.stack?String(error.stack):""});
  return true;
};
window.addEventListener("unhandledrejection",function(e){
  const r=e&&e.reason;
  send("webview_js_error",{message:r&&r.message?String(r.message):String(r||"Unhandled promise rejection"),stack:r&&r.stack?String(r.stack):""});
});

function valid(p){return !!p&&Number.isFinite(Number(p.latitude))&&Number.isFinite(Number(p.longitude));}
function point(p){return [Number(p.latitude),Number(p.longitude)];}
function idOf(d){return String(d&&(d.id||d.docId||d.userId||d.phone||"unknown"));}
function vehicleType(d){return String(d&&d.vehicleType||"").toLowerCase();}

if(typeof L==="undefined"){send("webview_js_error",{message:"Leaflet n'est pas chargé"});return;}
if(!valid(PASSENGER)){send("webview_js_error",{message:"Position passager invalide"});return;}

const map=L.map("map",{zoomControl:false,attributionControl:true}).setView(point(PASSENGER),15);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap contributors"}).addTo(map);

const passengerSvg='<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><path d="M16 2.5a7 7 0 1 1 0 14 7 7 0 0 1 0-14ZM6 29.5c.9-6.1 4.3-9.2 10-9.2s9.1 3.1 10 9.2H6Z" fill="#16a34a"/></svg>';
const carSvg='<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><path d="M7 8.5h18l2.6 8H29a2 2 0 0 1 2 2v6h-3v2h-4v-2H8v2H4v-2H1v-6a2 2 0 0 1 2-2h1.4l2.6-8Z" fill="#111827"/><circle cx="7" cy="23" r="2.5" fill="#fff"/><circle cx="25" cy="23" r="2.5" fill="#fff"/></svg>';
const motoSvg='<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="23" r="4" fill="#111827"/><circle cx="24" cy="23" r="4" fill="#111827"/><path d="M8 23h6l3-7h5l2 7h-4l-2-5h-4l-2 5H8Zm5-9h5l-2-4h-4l1 4Zm5 0 3-3 3 3" fill="none" stroke="#111827" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
function icon(svg,size,className){return L.divIcon({html:svg,className:className,iconSize:[size,size],iconAnchor:[size/2,size/2]});}
const passengerIcon=icon(passengerSvg,30,"passenger-icon");
const carIcon=icon(carSvg,28,"vehicle-icon");
const motoIcon=icon(motoSvg,27,"vehicle-icon");

let passengerMarker=null;
let driverMarkers={};
let searchLineLayer=null;
let pickupRouteLayer=null;
let destinationRouteLayer=null;
let pickupRoutePoints=[];
let destinationRoutePoints=[];
let pickupRouteActive=false;
let destinationRouteActive=false;
let routeRequestRunning=false;
let destinationRequestRunning=false;
let searchingDriverId=null;
const ARRIVAL_THRESHOLD_METERS=25;

function showPassenger(){
  if(!passengerMarker&&valid(PASSENGER)) passengerMarker=L.marker(point(PASSENGER),{icon:passengerIcon,zIndexOffset:1200}).addTo(map);
  debug("Marqueur passager créé");
}
function hidePassenger(){
  if(passengerMarker){try{if(map.hasLayer(passengerMarker))map.removeLayer(passengerMarker);}catch(e){} passengerMarker=null;debug("Marqueur passager supprimé : conducteur arrivé");}
}
function distance(a,b){return map.distance([Number(a.latitude),Number(a.longitude)],[Number(b.latitude),Number(b.longitude)]);}
function clearSearchLine(){if(searchLineLayer){try{if(map.hasLayer(searchLineLayer))map.removeLayer(searchLineLayer);}catch(e){}searchLineLayer=null;}searchingDriverId=null;}
function drawSearchLine(d){
  // Avant acceptation, aucune ligne ne doit être affichée.
  // Le passager voit uniquement les conducteurs disponibles.
  clearSearchLine();
  searchingDriverId=null;
}
function clearDrivers(){
  Object.keys(driverMarkers).forEach(function(id){const m=driverMarkers[id];try{if(m&&map.hasLayer(m))map.removeLayer(m);}catch(e){}delete driverMarkers[id];});
}
function showDrivers(list,fit){
  if(!Array.isArray(list))list=[];
  const active=new Set();
  list.forEach(function(d){
    if(!valid(d))return;
    const id=idOf(d); if(!id||id==="unknown")return;
    active.add(id);
    const pos=point(d);
    let marker=driverMarkers[id];
    if(marker){marker._driverData=d;animateMarker(marker,pos);return;}
    marker=L.marker(pos,{icon:vehicleType(d)==="moto"||vehicleType(d)==="motorbike"?motoIcon:carIcon,zIndexOffset:1000}).addTo(map);
    marker._driverData=d;
    marker.bindTooltip(d.name||"Conducteur",{direction:"top",offset:[0,-12]});
    marker.on("click",function(){send("driver_selected",{driver:d});});
    driverMarkers[id]=marker;
  });
  Object.keys(driverMarkers).forEach(function(id){if(!active.has(id)){const m=driverMarkers[id];try{if(map.hasLayer(m))map.removeLayer(m);}catch(e){}delete driverMarkers[id];}});
  debug("Conducteurs affichés : "+Object.keys(driverMarkers).length);
  if(fit&&list.length){const bounds=L.latLngBounds([point(PASSENGER)]);list.forEach(function(d){if(valid(d))bounds.extend(point(d));});if(bounds.isValid())map.fitBounds(bounds,{padding:[60,60],maxZoom:16});}
}

function animateMarker(marker, pos) {
  if (
    !marker ||
    !Array.isArray(pos) ||
    pos.length < 2 ||
    !Number.isFinite(Number(pos[0])) ||
    !Number.isFinite(Number(pos[1]))
  ) {
    return;
  }

  if (marker._frame) {
    cancelAnimationFrame(marker._frame);
    marker._frame = null;
  }

  const start = marker.getLatLng();
  const end = L.latLng(Number(pos[0]), Number(pos[1]));
  const startedAt = performance.now();
  const duration = 450;

  function frame(now) {
    const progress = Math.min((now - startedAt) / duration, 1);

    const lat = start.lat + (end.lat - start.lat) * progress;
    const lng = start.lng + (end.lng - start.lng) * progress;
    const currentPosition = [lat, lng];

    marker.setLatLng(currentPosition);

    // Faire progresser la route pendant le déplacement du marqueur.
    if (pickupRouteActive && !destinationRouteActive) {
      trimRoute(
        pickupRouteLayer,
        pickupRoutePoints,
        currentPosition,
        "pickup"
      );
    } else if (destinationRouteActive) {
      trimRoute(
        destinationRouteLayer,
        destinationRoutePoints,
        currentPosition,
        "destination"
      );
    }

    if (progress < 1) {
      marker._frame = requestAnimationFrame(frame);
    } else {
      marker.setLatLng(end);
      marker._frame = null;
    }
  }

  marker._frame = requestAnimationFrame(frame);
}

function removeLayer(layer){if(layer){try{if(map.hasLayer(layer))map.removeLayer(layer);}catch(e){}}}

function trimRoute(layer, points, pos, arrivalType) {
  if (!layer || !Array.isArray(points) || points.length < 2) {
    return;
  }

  // Vérifier l'arrivée au véritable point final de la route,
  // et non la proximité d'un point quelconque sur le trajet.
  const endpoint = points[points.length - 1];

  if (map.distance(pos, endpoint) <= ARRIVAL_THRESHOLD_METERS) {
    removeLayer(layer);

    if (arrivalType === "pickup") {
      pickupRouteActive = false;
      pickupRoutePoints = [];
      pickupRouteLayer = null;
      hidePassenger();

      debug("Conducteur arrivé au passager : route pickup terminée");
    } else {
      destinationRouteActive = false;
      destinationRoutePoints = [];
      destinationRouteLayer = null;

      debug("Conducteur arrivé à destination : route destination terminée");
    }

    return;
  }

  // L'index ne peut avancer que dans le sens du trajet.
  const previousIndex = Number(layer._progressIndex) || 0;
  let nearestIndex = previousIndex;
  let bestDistance = Infinity;

  for (let i = previousIndex; i < points.length; i++) {
    const currentDistance = map.distance(pos, points[i]);

    if (currentDistance < bestDistance) {
      bestDistance = currentDistance;
      nearestIndex = i;
    }
  }

  layer._progressIndex = Math.max(previousIndex, nearestIndex);

  // Masquer la partie déjà parcourue et conserver la suite du trajet.
  const nextIndex = Math.min(layer._progressIndex + 1, points.length - 1);
  const remainingPoints = [pos].concat(points.slice(nextIndex));

  if (remainingPoints.length >= 2) {
    layer.setLatLngs(remainingPoints);
  }
}

async function fetchRoute(from,to){
  const url="https://router.project-osrm.org/route/v1/driving/"+from[1]+","+from[0]+";"+to[1]+","+to[0]+"?overview=full&geometries=geojson";
  const response=await fetch(url); if(!response.ok)throw new Error("OSRM HTTP "+response.status);
  const data=await response.json(); if(!data.routes||!data.routes.length)throw new Error("Aucune route OSRM");
  return data.routes[0];
}
async function startPickupRoute(d){
  if(!valid(d)||routeRequestRunning||destinationRouteActive)return;
  routeRequestRunning=true;
  try{
    const route=await fetchRoute(point(d),point(PASSENGER));
    pickupRoutePoints=route.geometry.coordinates.map(function(p){return [p[1],p[0]];});
    pickupRoutePoints.unshift(point(d));
    pickupRoutePoints.push(point(PASSENGER));
    removeLayer(pickupRouteLayer);
    pickupRouteLayer=L.polyline(pickupRoutePoints,{color:"#16a34a",weight:5,opacity:.92,lineCap:"round",lineJoin:"round"}).addTo(map);
    pickupRouteActive=true;
    pickupRouteLayer.bringToFront();
    send("route_info",{distance:route.distance,duration:route.duration,eta:Date.now()+route.duration*1000});
    debug("Route conducteur → passager créée");
  }catch(e){send("webview_js_error",{message:"Route pickup : "+String(e)});}finally{routeRequestRunning=false;}
}
function stopPickupRoute(){pickupRouteActive=false;pickupRoutePoints=[];removeLayer(pickupRouteLayer);pickupRouteLayer=null;}
async function startDestinationRoute(d,dest){
  if(!valid(d)||!valid(dest)||destinationRequestRunning)return;
  destinationRequestRunning=true;
  stopPickupRoute();
  clearSearchLine();
  try{
    const route=await fetchRoute(point(d),point(dest));
    destinationRoutePoints=route.geometry.coordinates.map(function(p){return [p[1],p[0]];});
    destinationRoutePoints.unshift(point(d));
    destinationRoutePoints.push(point(dest));
    removeLayer(destinationRouteLayer);
    destinationRouteLayer=L.polyline(destinationRoutePoints,{color:"#16a34a",weight:5,opacity:.92,lineCap:"round",lineJoin:"round"}).addTo(map);
    destinationRouteActive=true;
    destinationRouteLayer.bringToFront();
    send("destination_route_info",{distance:route.distance,duration:route.duration,eta:Date.now()+route.duration*1000});
    debug("Route conducteur → destination créée");
  }catch(e){send("webview_js_error",{message:"Route destination : "+String(e)});}finally{destinationRequestRunning=false;}
}
function stopDestinationRoute(){destinationRouteActive=false;destinationRoutePoints=[];removeLayer(destinationRouteLayer);destinationRouteLayer=null;}

function updateDriverPosition(d) {
  if (!valid(d)) {
    return;
  }

  const id = idOf(d);

  if (!id || id === "unknown") {
    return;
  }

  let marker = driverMarkers[id];

  if (!marker) {
    showDrivers([d], false);
    marker = driverMarkers[id];

    if (!marker) {
      return;
    }

    marker._driverData = d;

    // Initialiser la progression si la route existe déjà.
    if (pickupRouteActive && !destinationRouteActive) {
      trimRoute(
        pickupRouteLayer,
        pickupRoutePoints,
        point(d),
        "pickup"
      );
    } else if (destinationRouteActive) {
      trimRoute(
        destinationRouteLayer,
        destinationRoutePoints,
        point(d),
        "destination"
      );
    }

    return;
  }

  marker._driverData = d;

  // La ligne sera mise à jour à chaque image de l'animation.
  animateMarker(marker, point(d));
}

function showAcceptedDriver(d){
  if(!d)return;
  clearSearchLine();
  stopDestinationRoute();
  clearDrivers();
  showDrivers([d],true);
  startPickupRoute(d);
  debug("Conducteur accepté affiché en mode tracking : "+(d.name||idOf(d)));
}

window.__ntaakataReceiveMessage=function(message){
  try{
    let data=message; if(typeof data==="string")data=JSON.parse(data); if(!data)return;
    if(data.type==="drivers_update"){
      if(MODE!=="drivers")return;
      showDrivers(data.drivers||[],true);
      return;
    }
    if(data.type==="searching_driver"){
      if(MODE!=="drivers")return;
      if(data.driver)drawSearchLine(data.driver);else clearSearchLine();
      return;
    }
    if(data.type==="driver_route"||data.type==="show_driver_route"){
      if(MODE!=="tracking")return;
      showAcceptedDriver(data.driver);return;
    }
    if(data.type==="driver_position"){
      if(MODE!=="tracking")return;
      updateDriverPosition(data.driver);return;
    }
    if(data.type==="stop_routes"){
      stopPickupRoute();clearSearchLine();return;
    }
    if(data.type==="start_destination_route"){
      if(MODE!=="tracking")return;
      const d=data.driver; const dest=data.destination||data.destinationLocation||INITIAL_DESTINATION;
      if(d&&dest)startDestinationRoute(d,dest);return;
    }
    if(data.type==="stop_destination_route"){stopDestinationRoute();return;}
    if(data.type==="tracking_driver"){
      if(MODE!=="tracking")return;
      showAcceptedDriver(data.driver);return;
    }
    if(data.type==="clear_search"){clearSearchLine();return;}
  }catch(e){send("webview_js_error",{message:"Réception message : "+String(e),stack:e&&e.stack?String(e.stack):""});}
};

document.addEventListener("message",function(e){window.__ntaakataReceiveMessage(e.data);});
window.addEventListener("message",function(e){window.__ntaakataReceiveMessage(e.data);});

showPassenger();
if(MODE==="drivers"){
  showDrivers(INITIAL_DRIVERS,true);
  if(SEARCHING_DRIVER)drawSearchLine(SEARCHING_DRIVER);
}else if(MODE==="tracking"&&INITIAL_DRIVER){
  showAcceptedDriver(INITIAL_DRIVER);
}
if(INITIAL_DESTINATION&&MODE==="tracking"&&INITIAL_DRIVER){
  // La destination ne démarre pas automatiquement : React Native l'active explicitement.
}

map.whenReady(function(){debug("WebView Leaflet prête");send("ready");});
})();
</script>
</body>
</html>`;
}
